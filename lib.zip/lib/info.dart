import 'package:flutter/material.dart';

class InfoPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('About App')),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Mini Project – Day 5',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            SizedBox(height: 10),
            Text('This app was is built by: Flutter WEB'),
            SizedBox(height: 10),
            Text('Developer: Altina Brahimi'),
            SizedBox(height: 10),
            Text('Use: setState(), navigation, SnackBar and ListView.'),
            Spacer(),
            Center(
              child: Text(
                '© 2025 All rights reserved.',
                style: TextStyle(color: Colors.grey),
              ),
            )
          ],
        ),
      ),
    );
  }
}
