import 'package:flutter/material.dart';

class HomePage extends StatefulWidget {
  static List<String> items = [];

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Home Page'),
        actions: [
          IconButton(
            icon: Icon(Icons.info_outline),
            onPressed: () => Navigator.pushNamed(context, '/info'),
          ),
        ],
      ),
      body: HomePage.items.isEmpty
          ? Center(child: Text('No items yet. Add some!'))
          : ListView.builder(
              itemCount: HomePage.items.length,
              itemBuilder: (context, index) {
                final item = HomePage.items[index];
                return Card(
                  margin: EdgeInsets.all(8),
                  child: ListTile(
                    title: Text(item),
                    trailing: IconButton(
                      icon: Icon(Icons.delete, color: Colors.red),
                      onPressed: () {
                        setState(() {
                          HomePage.items.removeAt(index);
                        });
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(content: Text('Item deleted')),
                        );
                      },
                    ),
                  ),
                );
              },
            ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => Navigator.pushNamed(context, '/add')
            .then((_) => setState(() {})),
        child: Icon(Icons.add),
      ),
    );
  }
}
