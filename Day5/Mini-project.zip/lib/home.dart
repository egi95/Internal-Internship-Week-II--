import 'package:flutter/material.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final List<String> _items = ['Artikulli 1', 'Artikulli 2', 'Artikulli 3'];

  Future<void> _goToAdd() async {
    final result = await Navigator.pushNamed(context, '/add');
    if (result is String && result.trim().isNotEmpty) {
      setState(() {
        _items.add(result.trim());
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('U shtua: $result')),
      );
    }
  }

  void _deleteAt(int index) {
    final removed = _items[index];
    setState(() {
      _items.removeAt(index);
    });
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('U fshi: $removed')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Lista e artikujve'),
        actions: [
          IconButton(
            tooltip: 'Info',
            onPressed: () => Navigator.pushNamed(context, '/about'),
            icon: const Icon(Icons.info_outline),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text(
              'Faqja 1: Home/List',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Expanded(
              child: _items.isEmpty
                  ? const Center(child: Text('Lista eshte bosh'))
                  : ListView.builder(
                      itemCount: _items.length,
                      itemBuilder: (context, index) {
                        final text = _items[index];
                        return Card(
                          child: ListTile(
                            title: Text(text),
                            trailing: IconButton(
                              icon: const Icon(Icons.delete_outline),
                              onPressed: () => _deleteAt(index),
                            ),
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _goToAdd,
        label: const Text('Shto'),
        icon: const Icon(Icons.add),
      ),
    );
  }
}
