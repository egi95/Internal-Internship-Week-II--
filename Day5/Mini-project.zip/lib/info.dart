import 'package:flutter/material.dart';

class InfoPage extends StatelessWidget {
  const InfoPage({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Rreth aplikacionit')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: const [
            Text(
              'Faqja 3: Info/About',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 8),
            Text('Aplikacion offline me 3 faqe per Day 4.'),
            SizedBox(height: 4),
            Text(
                'Permban: Liste ne memorie, forme shtimi, setState, SnackBar, Navigator.'),
          ],
        ),
      ),
    );
  }
}
