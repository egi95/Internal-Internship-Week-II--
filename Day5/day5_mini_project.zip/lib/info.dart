import 'package:flutter/material.dart';

class InfoPage extends StatelessWidget {
  const InfoPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Rreth Aplikacionit')),
      body: const Center(
        child: Padding(
          padding: EdgeInsets.all(20),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text('📘 Mini Flutter Web App',
                  style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
              SizedBox(height: 10),
              Text('Ky aplikacion është ndërtuar si projekt praktik i Day 5.'),
              SizedBox(height: 10),
              Text('Autori: Aris Mernica'),
              SizedBox(height: 10),
              Text('Përdor Flutter, FutureBuilder, http dhe navigim.'),
            ],
          ),
        ),
      ),
    );
  }
}
