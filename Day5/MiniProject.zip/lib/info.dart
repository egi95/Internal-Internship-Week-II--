import 'package:flutter/material.dart';

class InfoScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('About App')),
      body: Padding(
        padding: EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Simple Flutter Web App',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            SizedBox(height: 10),
            Text('This app was created as part of Day 4 learning.'),
            SizedBox(height: 10),
            Text('It demonstrates:'),
            Text('- FutureBuilder for fetching data'),
            Text('- Navigator for page transitions'),
            Text('- SnackBar for error handling'),
            Text('- setState() for refreshing'),
            SizedBox(height: 20),
            Text('Author: Student Example',
                style: TextStyle(fontStyle: FontStyle.italic)),
          ],
        ),
      ),
    );
  }
}
