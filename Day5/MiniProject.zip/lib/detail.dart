import 'package:flutter/material.dart';

class DetailScreen extends StatelessWidget {
  final String title;
  final String body;

  DetailScreen({required this.title, required this.body});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Post Details')),
      body: Padding(
        padding: EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Title:', style: TextStyle(fontWeight: FontWeight.bold)),
            SizedBox(height: 5),
            Text(title, style: TextStyle(fontSize: 18)),
            SizedBox(height: 20),
            Text('Body:', style: TextStyle(fontWeight: FontWeight.bold)),
            SizedBox(height: 5),
            Text(body),
          ],
        ),
      ),
    );
  }
}
