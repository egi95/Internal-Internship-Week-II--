import 'package:flutter/material.dart';

class InfoPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Rreth aplikacionit')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Mini Project – Day 5 (Offline)',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            SizedBox(height: 12),
            Text(
              'Ky aplikacion demonstron përdorimin e List, setState dhe navigimit '
              'në Flutter pa përdorur ndonjë API të jashtme.',
            ),
            SizedBox(height: 12),
            Text('Autori: Daris Aliu'),
            SizedBox(height: 8),
            Text('Viti: 2025'),
          ],
        ),
      ),
    );
  }
}
