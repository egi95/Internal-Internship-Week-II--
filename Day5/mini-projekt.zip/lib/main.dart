import 'package:flutter/material.dart';
import 'home.dart';
import 'add_page.dart';
import 'info.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Mini Project – Day 5 (Offline)',
      theme: ThemeData(primarySwatch: Colors.teal),
      home: HomePage(),
      routes: {
        '/add': (context) => AddPage(),
        '/info': (context) => InfoPage(),
      },
    );
  }
}
