package com.example.mini_projekt

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
