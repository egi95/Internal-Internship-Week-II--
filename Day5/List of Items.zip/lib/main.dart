import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Mini Flutter Web App',
      home: HomeScreen(),
    );
  }
}

// ---------------- Home Screen ----------------
class HomeScreen extends StatefulWidget {
  @override
  HomeScreenState createState() => HomeScreenState();
}

class HomeScreenState extends State<HomeScreen> {
  List<String> items = ['Apple', 'Banana', 'Orange'];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Home / List'),
        actions: [
          IconButton(
            icon: Icon(Icons.info_outline),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => InfoScreen()),
              );
            },
          ),
          IconButton(
            icon: Icon(Icons.add),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => AddScreen()),
              ).then((result) {
                if (result != null) {
                  setState(() {
                    items.add(result);
                  });
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text(result + ' added!')),
                  );
                }
              });
            },
          ),
        ],
      ),
      body: items.length == 0
          ? Center(child: Text('No items yet.'))
          : ListView.builder(
              itemCount: items.length,
              itemBuilder: (context, index) {
                String item = items[index];
                return ListTile(
                  title: Text(item),
                  trailing: IconButton(
                    icon: Icon(Icons.delete),
                    onPressed: () {
                      setState(() {
                        items.removeAt(index);
                      });
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text(item + ' removed!')),
                      );
                    },
                  ),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => DetailScreen(item),
                      ),
                    );
                  },
                );
              },
            ),
    );
  }
}

// ---------------- Add Screen ----------------
class AddScreen extends StatelessWidget {
  TextEditingController controller = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Add Item')),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              controller: controller,
              decoration: InputDecoration(
                labelText: 'Item name',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 16),
            ElevatedButton(
              child: Text('Add'),
              onPressed: () {
                if (controller.text != '') {
                  Navigator.pop(context, controller.text);
                }
              },
            ),
          ],
        ),
      ),
    );
  }
}

// ---------------- Detail Screen ----------------
class DetailScreen extends StatelessWidget {
  String item;
  DetailScreen(this.item);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Detail')),
      body: Center(
        child: Text('Selected item: ' + item, style: TextStyle(fontSize: 24)),
      ),
    );
  }
}

// ---------------- Info Screen ----------------
class InfoScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('About App')),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Mini Flutter Web App', style: TextStyle(fontSize: 24)),
            SizedBox(height: 16),
            Text('Author: Anisa Ratkoceri'),
            Text('This app demonstrates:'),
            Text('- Home/List page'),
            Text('- Add/Detail page'),
            Text('- Info/About page'),
            SizedBox(height: 16),
            Text('Built with Flutter Web (Day 5 project).'),
          ],
        ),
      ),
    );
  }
}
